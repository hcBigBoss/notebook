package com.itheima.test18;

public class LinkedListDemo {
    public static void main(String[] args) {
        /**
         * 单列集合：有序且可重复
         * 底层是一个双向链表？
         *
         *
         *
         */


    }
}
