package com.itheima.test18;

public class HashSetDemo {
    public static void main(String[] args) {
        /**
         * 存储特点：无序且不可重复
         * 为什么无序？为什么重复？
         * HashSet 源码，最好看的源码
         * 1.核心属性  2.核心构造方法  3.核心方法
         * hashSet底层就是一个hashMap集合
         * hashSet  = hashMap 的key
         * 重点：hashset的存储，依赖于hashMap的key value(Object)
         */
    }
}
